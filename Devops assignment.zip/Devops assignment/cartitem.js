import React, { useState } from "react";

const bikes = [
  { id: 1, name: "Royal Enfield Classic 350", price: 220000, accent: "#dc2626" },
  { id: 2, name: "Royal Enfield Bullet 350", price: 210000, accent: "#7c3aed" },
  { id: 3, name: "Yamaha R15", price: 185000, accent: "#2563eb" },
  { id: 4, name: "KTM Duke 390", price: 320000, accent: "#ea580c" },
  { id: 5, name: "KTM RC 200", price: 250000, accent: "#f97316" },
  { id: 6, name: "TVS Apache RTR 200", price: 170000, accent: "#059669" },
  { id: 7, name: "Bajaj Pulsar NS200", price: 155000, accent: "#0d9488" },
  { id: 8, name: "Suzuki Gixxer", price: 145000, accent: "#0284c7" },
  { id: 9, name: "Honda CB350", price: 240000, accent: "#b91c1c" },
  { id: 10, name: "BMW G310R", price: 295000, accent: "#1e293b" },
];

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (bike) => {
    setCart([...cart, bike]);
  };

  const totalPrice = cart.reduce((sum, bike) => sum + bike.price, 0);

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "linear-gradient(180deg, #f8fafc, #eef2ff)",
        fontFamily: "Inter, Arial, sans-serif",
        padding: "30px",
      }}
    >
      {/* Header */}
      <h1
        style={{
          textAlign: "center",
          color: "#0f172a",
          marginBottom: "35px",
        }}
      >
        🏍️ Manikanta Bikes
      </h1>

      {/* Bike Cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
          gap: "22px",
          maxWidth: "1200px",
          margin: "0 auto",
        }}
      >
        {bikes.map((bike) => (
          <div
            key={bike.id}
            style={{
              backgroundColor: "#ffffff",
              borderRadius: "14px",
              padding: "18px",
              position: "relative",
              boxShadow: "0 8px 20px rgba(0,0,0,0.08)",
              borderTop: `5px solid ${bike.accent}`,
            }}
          >
            {/* Accent Dot */}
            <span
              style={{
                position: "absolute",
                top: "14px",
                right: "14px",
                width: "12px",
                height: "12px",
                backgroundColor: bike.accent,
                borderRadius: "50%",
              }}
            />

            <h3 style={{ color: "#0f172a", marginBottom: "8px" }}>
              {bike.name}
            </h3>

            <p
              style={{
                color: bike.accent,
                fontWeight: "600",
                marginBottom: "16px",
              }}
            >
              ₹{bike.price.toLocaleString()}
            </p>

            <button
              onClick={() => addToCart(bike)}
              style={{
                width: "100%",
                backgroundColor: bike.accent,
                color: "#ffffff",
                border: "none",
                padding: "10px",
                borderRadius: "8px",
                fontWeight: "600",
                cursor: "pointer",
              }}
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>

      {/* Cart Section */}
      <div
        style={{
          maxWidth: "600px",
          margin: "45px auto 0",
          backgroundColor: "#ffffff",
          borderRadius: "14px",
          padding: "25px",
          boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
          borderLeft: "6px solid #2563eb",
        }}
      >
        <h2 style={{ color: "#0f172a", marginBottom: "15px" }}>
          🛒 Cart Summary
        </h2>

        {cart.length === 0 ? (
          <p style={{ color: "#64748b" }}>Your cart is empty</p>
        ) : (
          <ul style={{ paddingLeft: "20px", color: "#334155" }}>
            {cart.map((item, index) => (
              <li key={index}>
                {item.name} – ₹{item.price.toLocaleString()}
              </li>
            ))}
          </ul>
        )}

        <hr style={{ margin: "18px 0" }} />

        <h3 style={{ color: "#16a34a", fontWeight: "700" }}>
          Total: ₹{totalPrice.toLocaleString()}
        </h3>
      </div>
    </div>
  );
}

export default App;
